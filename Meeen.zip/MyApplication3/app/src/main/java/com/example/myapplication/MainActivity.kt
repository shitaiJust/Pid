package com.example.myapplication

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.CalendarContract.CalendarCache.URI
import android.view.View
import android.widget.ImageView
import android.widget.TextView


class Student(var Name: String, var Surname: String,var Age: Int,var Group: Int){
}
class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
    val Egor=Student("Egor","Kostin",19,3)
    val Ego1=Student("Dim","Kotlin",12,2)
    val Ego2=Student("Mouse","Kostin",15,3)
    val Ego3=Student("Free","Koupon",19,3)
    val Ego4=Student("Teleport","Kostin",11,3)
    var list= listOf<Student>(Egor,Ego1,Ego2,Ego3,Ego4)
    var count=0
    @SuppressLint("SetTextI18n")
    fun left(view: View) {
        count =count- 1
        if(count==-1){count=4}
        val textView = findViewById<TextView>(R.id.TextView)
        when (count) {
            0 -> textView.text =
                Egor.Name + " " + Egor.Surname + " " + Egor.Age + "лет " + Egor.Group + "группа"
            1 -> textView.text =
                Ego1.Name + " " + Ego1.Surname + " " + Ego1.Age + "лет " + Ego1.Group + "группа"
            2 -> textView.text =
                Ego2.Name + " " + Ego2.Surname + " " + Ego2.Age + "лет " + Ego2.Group + "группа"
            3 -> textView.text =
                Ego3.Name + " " + Ego3.Surname + " " + Ego3.Age + "лет " + Ego3.Group + "группа"
            4 -> textView.text =
                Ego4.Name + " " + Ego4.Surname + " " + Ego4.Age + "лет " + Ego4.Group + "группа"
        }
    }
    fun right(view: View){
        count += 1
        if(count==5){count=0}
        val textView = findViewById<TextView>(R.id.TextView)
        val img=findViewById<ImageView>(R.id.imageView)

        when(count){
            0->textView.text=Egor.Name+" "+Egor.Surname+" "+Egor.Age+"лет "+Egor.Group+"группа"
            1->textView.text=Ego1.Name+" "+Ego1.Surname+" "+Ego1.Age+"лет "+Ego1.Group+"группа"
            2->textView.text=Ego2.Name+" "+Ego2.Surname+" "+Ego2.Age+"лет "+Ego2.Group+"группа"
            3->textView.text=Ego3.Name+" "+Ego3.Surname+" "+Ego3.Age+"лет "+Ego3.Group+"группа"
            4->textView.text=Ego4.Name+" "+Ego4.Surname+" "+Ego4.Age+"лет "+Ego4.Group+"группа"
        }

    }





}




